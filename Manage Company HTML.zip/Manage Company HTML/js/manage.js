  function openDelete() {
    document.getElementById("deleteForm").style.display = "block";
  }

  function openEdit() {
    document.getElementById("editForm").style.display = "block";
  }

  function closeDelete() {
    document.getElementById("deleteForm").style.display = "none";
  }

  function closeEdit() {
    document.getElementById("editForm").style.display = "none";
  }